import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { StockpricePage } from './stockprice.page';

const routes: Routes = [
  {
    path: '',
    component: StockpricePage
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class StockpricePageRoutingModule {}
