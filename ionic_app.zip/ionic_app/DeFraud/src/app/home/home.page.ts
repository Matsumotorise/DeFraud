import { Component, OnInit } from '@angular/core';
import { Publickey } from './Publickey.model';

@Component({
  selector: 'app-home',
  templateUrl: './home.page.html',
  styleUrls: ['./home.page.scss'],
})
export class HomePage implements OnInit {
  keys: Publickey[] = [
    {
      id: 1,
      key: 'gcybao278iasi283ndos'
    },
    {
      id: 2,
      key: 'ionua283aohducbxxx8s'
    },
    {
      id: 3,
      key: 'uemnuciab639abfoa83'
    }
  ];

  constructor() { }

  ngOnInit() {
  }

}
