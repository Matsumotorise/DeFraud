export interface Publickey {
  id: number;
  key: string;
}
